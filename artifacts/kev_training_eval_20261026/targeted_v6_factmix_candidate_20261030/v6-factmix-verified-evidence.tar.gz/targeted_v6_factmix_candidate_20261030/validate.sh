#!/usr/bin/env bash
set -euo pipefail
ROOT=/C20545/kev-08b-official-repro-20261026
DATA="$ROOT/targeted_v6_factmix_candidate_20261030"
export CUDA_VISIBLE_DEVICES='' HF_HOME="$ROOT/hf" HF_HUB_OFFLINE=1 PYTHONPATH="$ROOT/stages/stage3" PYTHONUNBUFFERED=1
trap 'c=$?; if [ "$c" -ne 0 ]; then echo "failed:$c" > "$DATA/validation_status.txt"; fi' EXIT
echo augmentation > "$DATA/validation_status.txt"
"$ROOT/python.sh" "$ROOT/verify_kev_factmix_augmentation.py" --code-root "$ROOT/stages/stage3" --original "$ROOT/targeted_v6_20261030/train.jsonl" --candidate "$DATA/train.jsonl" --out "$DATA/augmentation_check.json"
echo tokenization > "$DATA/validation_status.txt"
"$ROOT/python.sh" "$DATA/preflight.py" /C20545/models/Qwen3-0.6B-Base local-model-sha256-cd2a512003e2f9f3cd3c32a9c3573f820bb28c940f73c57b1ddaa983d9223eba "$DATA" "$ROOT/evals/v7/decision-v7" "$DATA/preflight_qwen3.json"
"$ROOT/python.sh" "$DATA/preflight.py" Qwen/Qwen3.5-0.8B-Base dc7cdfe2ee4154fa7e30f5b51ca41bfa40174e68 "$DATA" "$ROOT/evals/v7/decision-v7" "$DATA/preflight_qwen35.json"
echo complete > "$DATA/validation_status.txt"
